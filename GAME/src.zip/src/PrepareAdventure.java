import java.util.Scanner;

public class PrepareAdventure {
	//Edit your program in the area below only 
	static NPC npc1 = new NPC("Bee-Bee", 20);
	static Magician m1 = new Magician("Hades", 50, "Staff", "Mage shoe" );
	static DragonWarrior d1 = new DragonWarrior("WN1AP", 100, "Sword", "Dragon shoe", "Position");
	static Arrow a1 = new Arrow()
	//End here
	
	public static void main(String[] args) {
		
		//Edit your program in the area below only
		
		Scanner console = new Scanner(System.in);
		
		System.out.println("Are you ready for the next adventure?!?!?!?!");
		System.out.println("------------------------------------------------------------------");
		System.out.println("Please identify the character name: ");
		String name = console.next();
		
		System.out.println("Please create your character");
		System.out.println("--------------------------------");
		System.out.println("Press1 for Magician");
		System.out.println("Press2 for Dragon Warrior");
		System.out.println("--------------------------------");
		
		System.out.println("Enter your choice: ");
		int choice = console.nextInt();
		
		if(choice == 1) {
			System.out.println(m1);	
		}else if(choice == 2) {
			System.out.println(d1);;
		}else if(choice == 3) {
			System.out.println();;
		}else{
			System.out.println("The character is not exist!");
		}
		
		//End here

		startGame();
	}
	static void startGame(){
		System.out.println("=================Game Start!!=================");
		System.out.println(npc1);
		System.out.println(m1);
		System.out.println(m1.attack());
	}

}