
public interface useMagic {
	public String useMagic();
}
