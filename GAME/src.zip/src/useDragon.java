
public interface useDragon {
	public String useDragon();
}
