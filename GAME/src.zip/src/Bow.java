
public interface Bow {
	public String Bow();
}
